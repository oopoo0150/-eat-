package com.closet.great.dao;

public interface FollowDao {

}
