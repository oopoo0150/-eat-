package com.closet.great.dao;

public interface ContestDao {

}
