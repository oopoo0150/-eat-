package com.closet.great;

import org.springframework.stereotype.Controller;

@Controller
public class NotifyController {

}
