// JavaScript Document

$(window).load(function() {
    $('.flexslider').flexslider();
  });