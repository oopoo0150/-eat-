package com.closet.test2.dao;

import java.util.List;

import com.closet.test2.bean.ShareBoard;

public interface SBoardDao {

	boolean writeInsert(ShareBoard share);

	List<ShareBoard> getBoardList(int num);

	int getBoardCount(int num);

	ShareBoard getContents(Integer snum);

}
