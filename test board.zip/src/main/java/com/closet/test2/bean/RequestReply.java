package com.closet.test2.bean;

import org.apache.ibatis.type.Alias;

/*
@Alias("requestReply")
public class RequestReply {
	private int rebr_num;
	private String rebr_filename;
	private String rebr_content;
	private String rebr_select;
	private int rebr_complain;
	private int rebr_rebnum;
	private String rebr_sid;
	private int rebr_like;
	
	
	//detail(옷 정보 저장)
	private int red_num;
	private int red_rebnum;
	private int red_cldnum;
	
	
	public int getRebr_num() {
		return rebr_num;
	}
	public void setRebr_num(int rebr_num) {
		this.rebr_num = rebr_num;
	}
	public String getRebr_filename() {
		return rebr_filename;
	}
	public void setRebr_filename(String rebr_filename) {
		this.rebr_filename = rebr_filename;
	}
	public String getRebr_content() {
		return rebr_content;
	}
	public void setRebr_content(String rebr_content) {
		this.rebr_content = rebr_content;
	}
	public String getRebr_select() {
		return rebr_select;
	}
	public void setRebr_select(String rebr_select) {
		this.rebr_select = rebr_select;
	}
	public int getRebr_complain() {
		return rebr_complain;
	}
	public void setRebr_complain(int rebr_complain) {
		this.rebr_complain = rebr_complain;
	}
	public int getRebr_rebnum() {
		return rebr_rebnum;
	}
	public void setRebr_rebnum(int rebr_rebnum) {
		this.rebr_rebnum = rebr_rebnum;
	}
	public String getRebr_sid() {
		return rebr_sid;
	}
	public void setRebr_sid(String rebr_sid) {
		this.rebr_sid = rebr_sid;
	}
	public int getRebr_like() {
		return rebr_like;
	}
	public void setRebr_like(int rebr_like) {
		this.rebr_like = rebr_like;
	}
	public int getRed_num() {
		return red_num;
	}
	public void setRed_num(int red_num) {
		this.red_num = red_num;
	}
	public int getRed_rebnum() {
		return red_rebnum;
	}
	public void setRed_rebnum(int red_rebnum) {
		this.red_rebnum = red_rebnum;
	}
	public int getRed_cldnum() {
		return red_cldnum;
	}
	public void setRed_cldnum(int red_cldnum) {
		this.red_cldnum = red_cldnum;
	}

}
*/
