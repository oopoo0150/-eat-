package com.closet.test2.bean;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonFormat;


@Alias("infoReply")
public class InfoReply {
	private int inr_num;
	private String inr_content;
	@JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss", timezone = "Asia/Seoul")
	private Timestamp inr_date;
	private int inr_complain;
	private int inr_innum;
	private String inr_sid;
	
	private String compare;
	
	public String getCompare() {
		return compare;
	}
	public void setCompare(String compare) {
		this.compare = compare;
	}
	public int getInr_num() {
		return inr_num;
	}
	public void setInr_num(int inr_num) {
		this.inr_num = inr_num;
	}
	public String getInr_content() {
		return inr_content;
	}
	public void setInr_content(String inr_content) {
		this.inr_content = inr_content;
	}
	public Timestamp getInr_date() {
		return inr_date;
	}
	public void setInr_date(Timestamp inr_date) {
		this.inr_date = inr_date;
	}
	public int getInr_complain() {
		return inr_complain;
	}
	public void setInr_complain(int inr_complain) {
		this.inr_complain = inr_complain;
	}
	public int getInr_innum() {
		return inr_innum;
	}
	public void setInr_innum(int inr_innum) {
		this.inr_innum = inr_innum;
	}
	public String getInr_sid() {
		return inr_sid;
	}
	public void setInr_sid(String inr_sid) {
		this.inr_sid = inr_sid;
	}

}

