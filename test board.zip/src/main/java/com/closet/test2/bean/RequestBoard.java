package com.closet.test2.bean;

import java.sql.Date;

import org.apache.ibatis.type.Alias;


/*
// 게시판
@Alias("request")
public class RequestBoard {
	// 게시판 저장
	private int reb_num;
	private String reb_cate;
	private String reb_title;
	private String reb_weather;
	private Date reb_waerDate;
	private String reb_content;
	private String reb_clothes;
	private Date reb_date;
	private int reb_views;
	private int reb_complain;
	private String reb_sid;
	
	// 게시판 파일 저장
	private int rebi_num;
	private int rebi_rebnum;
	private int rebi_cldnum;
	
	
	public int getReb_num() {
		return reb_num;
	}
	public void setReb_num(int reb_num) {
		this.reb_num = reb_num;
	}
	public String getReb_cate() {
		return reb_cate;
	}
	public void setReb_cate(String reb_cate) {
		this.reb_cate = reb_cate;
	}
	public String getReb_title() {
		return reb_title;
	}
	public void setReb_title(String reb_title) {
		this.reb_title = reb_title;
	}
	public String getReb_weather() {
		return reb_weather;
	}
	public void setReb_weather(String reb_weather) {
		this.reb_weather = reb_weather;
	}
	public Date getReb_waerDate() {
		return reb_waerDate;
	}
	public void setReb_waerDate(Date reb_waerDate) {
		this.reb_waerDate = reb_waerDate;
	}
	public String getReb_content() {
		return reb_content;
	}
	public void setReb_content(String reb_content) {
		this.reb_content = reb_content;
	}
	public String getReb_clothes() {
		return reb_clothes;
	}
	public void setReb_clothes(String reb_clothes) {
		this.reb_clothes = reb_clothes;
	}
	public Date getReb_date() {
		return reb_date;
	}
	public void setReb_date(Date reb_date) {
		this.reb_date = reb_date;
	}
	public int getReb_views() {
		return reb_views;
	}
	public void setReb_views(int reb_views) {
		this.reb_views = reb_views;
	}
	public int getReb_complain() {
		return reb_complain;
	}
	public void setReb_complain(int reb_complain) {
		this.reb_complain = reb_complain;
	}
	public String getReb_sid() {
		return reb_sid;
	}
	public void setReb_sid(String reb_sid) {
		this.reb_sid = reb_sid;
	}
	public int getRebi_num() {
		return rebi_num;
	}
	public void setRebi_num(int rebi_num) {
		this.rebi_num = rebi_num;
	}
	public int getRebi_rebnum() {
		return rebi_rebnum;
	}
	public void setRebi_rebnum(int rebi_rebnum) {
		this.rebi_rebnum = rebi_rebnum;
	}
	public int getRebi_cldnum() {
		return rebi_cldnum;
	}
	public void setRebi_cldnum(int rebi_cldnum) {
		this.rebi_cldnum = rebi_cldnum;
	}	
	
	
}
*/